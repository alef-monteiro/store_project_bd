create view quantidade_vendas(id_funcionario, name, quantidade_vendida) as
SELECT f.id_funcionario,
       f.name,
       sum(pv.quantidade::numeric * pv.preco_unitario) AS quantidade_vendida
FROM funcionarios f
         JOIN vendas v ON f.id_funcionario = v.id_funcionario
         JOIN produto_venda pv ON v.id_venda = pv.id_venda
GROUP BY f.id_funcionario;

alter table quantidade_vendas
    owner to postgres;

