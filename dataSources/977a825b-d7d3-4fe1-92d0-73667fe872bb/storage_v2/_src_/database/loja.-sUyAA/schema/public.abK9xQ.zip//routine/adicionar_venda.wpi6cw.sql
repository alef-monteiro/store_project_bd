create procedure adicionar_venda(IN add_id_cliente integer, IN add_id_funcionario integer, IN add_data timestamp without time zone)
    language plpgsql
as
$$
BEGIN
    INSERT INTO vendas(id_cliente, id_funcionario, data)
    VALUES (add_id_cliente, add_id_funcionario, add_data);
end;
$$;

alter procedure adicionar_venda(integer, integer, timestamp) owner to postgres;

