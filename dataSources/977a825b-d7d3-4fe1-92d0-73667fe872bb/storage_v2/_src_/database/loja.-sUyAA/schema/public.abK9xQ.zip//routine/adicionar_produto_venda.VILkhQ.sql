create procedure adicionar_produto_venda(IN add_id_venda integer, IN add_id_produto integer, IN add_quantidade numeric, IN add_preco numeric)
    language plpgsql
as
$$
BEGIN
    INSERT INTO produto_venda(id_venda, id_produto, quantidade, preco_unitario)
    VALUES (add_id_venda, add_id_produto, add_quantidade, add_preco);
end;
$$;

alter procedure adicionar_produto_venda(integer, integer, numeric, numeric) owner to postgres;

