create function dias_antes(dias integer) returns timestamp without time zone
    language plpgsql
as
$$
BEGIN
    RETURN CURRENT_DATE - dias * INTERVAL '1 day';
end;
$$;

alter function dias_antes(integer) owner to postgres;

