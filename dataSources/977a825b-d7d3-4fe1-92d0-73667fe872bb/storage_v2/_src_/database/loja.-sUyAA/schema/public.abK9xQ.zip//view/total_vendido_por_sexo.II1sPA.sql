create view total_vendido_por_sexo(sexo, total_vendido) as
SELECT c.sexo,
       sum(pv.preco_unitario * pv.quantidade::numeric) AS total_vendido
FROM clientes c
         JOIN vendas v ON c.id = v.id_cliente
         JOIN produto_venda pv ON v.id_venda = pv.id_venda
GROUP BY c.sexo;

alter table total_vendido_por_sexo
    owner to postgres;

