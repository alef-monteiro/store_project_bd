create view total_item_por_sexo_funcionario(sexo, quantidade) as
SELECT f.sexo,
       count(v.id_venda) * sum(pv.quantidade) AS quantidade
FROM funcionarios f
         JOIN vendas v ON f.id_funcionario = v.id_funcionario
         JOIN produto_venda pv ON v.id_venda = pv.id_venda
GROUP BY f.sexo;

alter table total_item_por_sexo_funcionario
    owner to postgres;

