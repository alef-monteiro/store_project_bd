create procedure adicionar_funcionario(IN add_nome character varying, IN add_sexo character varying, IN add_ativo boolean, IN add_criado date, IN add_modificado date)
    language plpgsql
as
$$
BEGIN
    INSERT INTO funcionarios(name, sexo, ativo, criado_em, modificado_em)
    VALUES (add_nome, add_sexo, add_ativo, add_criado, add_modificado);
end;
$$;

alter procedure adicionar_funcionario(varchar, varchar, boolean, date, date) owner to postgres;

