create view preco_vendo_20percento(nome, preco_venda, preco_novo) as
SELECT p.nome,
       p.preco_venda,
       pv.preco_unitario * 2::numeric AS preco_novo
FROM produtos p
         JOIN produto_venda pv ON pv.id_produto = p.id_produto;

alter table preco_vendo_20percento
    owner to postgres;

