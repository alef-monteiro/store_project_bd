create procedure adicionar_produto(IN add_nome character varying, IN add_preco numeric, IN add_ativo boolean, IN add_criado timestamp without time zone, IN add_modificado timestamp without time zone)
    language plpgsql
as
$$
    BEGIN
        INSERT INTO produto(nome, preco_venda, ativo, criado_em, modificado_em)
        VALUES (add_nome, add_preco, add_ativo,
                add_criado, add_modificado
                );
    end;
$$;

alter procedure adicionar_produto(varchar, numeric, boolean, timestamp, timestamp) owner to postgres;

