create procedure add_cliente(IN add_nome character varying, IN add_sexo character varying, IN add_ativo boolean, IN add_criado_em timestamp without time zone, IN add_modificado_em timestamp without time zone)
    language plpgsql
as
$$
BEGIN
    INSERT INTO clientes(nome, sexo, ativo, criado_em, modificado_em)
    VALUES (add_nome, add_sexo, add_ativo, add_criado_em, add_modificado_em);
end;
$$;

alter procedure add_cliente(varchar, varchar, boolean, timestamp, timestamp) owner to postgres;

